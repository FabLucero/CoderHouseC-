﻿namespace Desafio2
{
    public partial class ApplicationCore : Application
    {
        public ApplicationCore()
        {
            InitializeComponent();

            PrimaryPage = new PrimaryPage();
        }
    }
}
