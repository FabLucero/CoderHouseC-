﻿namespace Desafio2
{
    public partial class PrimaryPage : ContentPage
    {
        public PrimaryPage()
        {
            InitializeComponent();
        }
    }
}
