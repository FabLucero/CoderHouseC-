﻿namespace Desafio2.Models;

public class Venta
{
    public int Id { get; set; }
    public string? Comentarios { get; set; }
    public int IdUsuario { get; set; }
}
